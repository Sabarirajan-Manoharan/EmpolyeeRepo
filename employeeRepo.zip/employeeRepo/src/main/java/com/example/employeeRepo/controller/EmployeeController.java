package com.example.employeeRepo.controller;


import com.example.employeeRepo.entity.Employee;
import com.example.employeeRepo.service.EmployeeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Optional;
@Tag(name = "Employee Controller", description = "Manage Employee Data")
@Controller
public class EmployeeController {

    private EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService){
        this.employeeService = employeeService;
    }

    @Operation(summary = "Display the employee form", description = "Renders the form for creating a new employee")
    @GetMapping("/index")
    public String showForm(Model model) {
        model.addAttribute("employee", new Employee());
        return "index";
    }

    @Operation(summary = "Save employee data", description = "Saves the employee data to the database")
    @PostMapping("/save")
    public String saveEmployee(@ModelAttribute Employee employee) {
        employeeService.saveEmployee(employee);
        return "redirect:/displayAll";
    }

    @Operation(summary = "List all employees", description = "Displays all employees in the database")
    @GetMapping("/displayAll")
    public String displayAllEmployees(Model model) {
        model.addAttribute("employees", employeeService.getAllEmployees());
        return "displayAll";
    }

    @Operation(summary = "Display a specific employee", description = "Displays the details of an employee by ID")
    @GetMapping("/display/{id}")
    public String displayEmployeeById(@PathVariable Long id, Model model) {
        Optional<Employee> employee = employeeService.getEmployeeById(id);
        if (employee.isPresent()) {
            model.addAttribute("employee", employee.get());
            return "display";
        }
        return "error"; // Create an error page if needed
    }
}
