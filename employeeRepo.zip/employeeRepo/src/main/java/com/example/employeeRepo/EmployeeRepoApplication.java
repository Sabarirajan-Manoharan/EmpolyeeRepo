package com.example.employeeRepo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeRepoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeRepoApplication.class, args);
	}

}
